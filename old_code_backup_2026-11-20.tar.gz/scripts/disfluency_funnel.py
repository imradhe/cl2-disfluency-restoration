#!/usr/bin/env python
"""Where do the gold disfluent tokens get lost? A per-type funnel for one pipeline output.

Every gold disfluent token of the scored part of the lecture is aligned (word by word, as in pipeline/score.py)
with the pipeline's output transcript and ends up in exactly one of
  * written by Whisper and tagged disfluent by the rules (uh / um / immediate repeat),
  * written by Whisper but not tagged (an ordinary word of the transcript; nothing in the pipeline can call it a
    disfluency, the model only inserts),
  * restored by the model with the right word,
  * missing: absent from the output. For these the phone recognizers are asked whether they had the evidence:
    the token's forced-aligned time span holds phones that match its G2P phones (>= 50% of them, in order), or for
    the one-phone "uh" a vowel. Reported for the espeak recognizer, the Telugu recognizer, and either of them.
Next to it, the model's own per-type F1 on the same part with *perfect* inputs (gold transcript, clean G2P phones of
everything said) and with the real recognizer phones, from scripts/eval_nptel_seq.py --from-frac 0.6.

Run: HF_HOME=.cache/hf HF_HUB_OFFLINE=1 .venv/bin/python -I scripts/disfluency_funnel.py --dir results/pipeline/english_001_cal_norm \
         --seq-eval results/nptel_seq_seq_cal_heldout.json
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nptel.recognized import split_tokens  # noqa: E402
from nptel.rsml import aligned_to_side  # noqa: E402
from nptel.streams import phone_stream, phones_between  # noqa: E402
from phones.channel import HES, HES_REF, VOWELS  # noqa: E402
from phones.g2p import G2P  # noqa: E402
from pipeline.asr import norm_word  # noqa: E402
from pipeline.score import GOLD_TYPES, align_idx, system_tokens  # noqa: E402


def lcs(a: list[str], b: list[str]) -> int:
    prev = [0] * (len(b) + 1)
    for x in a:
        cur = [0]
        for j, y in enumerate(b, 1):
            cur.append(prev[j - 1] + 1 if x == y else max(prev[j], cur[-1]))
        prev = cur
    return prev[-1]


def heard(ref: list[str], hyp: list[str], label: str) -> bool:
    """Did the recognizer write this token? One-phone "uh": any vowel; otherwise >= 50% of the G2P phones, in order."""
    if label == HES and tuple(ref) == HES_REF:
        return any(p in VOWELS for p in hyp)
    return bool(ref) and lcs(ref, hyp) / len(ref) >= 0.5


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=str(ROOT / "results/pipeline/english_001_cal_norm"))
    ap.add_argument("--aligned", default=str(ROOT / "data/nptel/raw/english_001/english_001.aligned.rsml"))
    ap.add_argument("--lex", default=str(ROOT / "data/raw/switchboard_ms98/sw-ms98-dict.text"))
    ap.add_argument("--from-frac", type=float, default=0.6)
    ap.add_argument("--rec", default=str(ROOT / "data/nptel/phones/english_001.jsonl"))
    ap.add_argument("--rec2", default=str(ROOT / "data/nptel/recognizers/xlsr53-te.jsonl"))
    ap.add_argument("--seq-eval", default="", help="results/nptel_seq_<ckpt>_heldout.json (perfect-input F1 per type)")
    ap.add_argument("--examples", type=int, default=6, help="most frequent words of the written-but-untagged tokens per type")
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    g2p = G2P.from_files(a.lex, ROOT / "configs/phonemap.yaml")
    toks = aligned_to_side(Path(a.aligned), sid="gold")["tokens"]
    cut = split_tokens(toks, a.from_frac) if a.from_frac > 0 else 0
    held = [t for t in toks[cut:] if t["label"] != "NOISE" and norm_word(t["spoken"])]
    gold = [(norm_word(t["spoken"]), t["label"] if t["label"] in GOLD_TYPES else "O") for t in held]
    t_from = toks[cut]["start"] if a.from_frac > 0 else 0.0
    j = json.loads((Path(a.dir) / "restored.json").read_text())
    sysd = system_tokens(j["tokens"], frozenset(), t_from=t_from)
    sw, gw = [w for w, _, _ in sysd], [w for w, _ in gold]
    g2s = {gi: si for si, gi in align_idx(sw, gw) if si is not None and gi is not None and sw[si] == gw[gi]}
    s1, s2 = phone_stream(Path(a.rec), "ipa", g2p.ipa), phone_stream(Path(a.rec2), "tel", g2p.ipa)

    cols = ["written, tagged by rules", "written, NOT tagged", "restored by the model", "missing"]
    funnel: dict[str, Counter] = defaultdict(Counter)
    untagged: dict[str, Counter] = defaultdict(Counter)
    for gi, (w, lab) in enumerate(gold):
        if lab not in GOLD_TYPES:
            continue
        si = g2s.get(gi)
        if si is None:
            c = funnel[lab]
            c["missing"] += 1
            t, ref = held[gi], list(g2p.phones(held[gi]["spoken"]))
            h1 = heard(ref, phones_between(s1, t["start"], t["end"]), lab)
            h2 = heard(ref, phones_between(s2, t["start"], t["end"]), lab)
            c["  heard by espeak"] += h1
            c["  heard by Telugu"] += h2
            c["  heard by either"] += h1 or h2
        else:
            _, s_lab, src = sysd[si]
            if src == "restored":
                funnel[lab]["restored by the model"] += 1
            elif s_lab is not None:
                funnel[lab]["written, tagged by rules"] += 1
            else:
                funnel[lab]["written, NOT tagged"] += 1
                untagged[lab][w] += 1
        funnel[lab]["gold"] += 1

    ceil = {}
    if a.seq_eval and Path(a.seq_eval).exists():
        r = json.loads(Path(a.seq_eval).read_text())["results"]
        for name in ("nptel_g2p_clean", "nptel_recognized"):
            ceil[name] = {t: v for t, v in r[name]["0.0"]["per_type"].items()}

    tot = Counter()
    print(f"gold disfluent tokens of the scored part, by what happened to them ({Path(a.dir).name}):\n")
    print(f"{'type':19s}{'gold':>5s} | {cols[0]:>25s}{cols[1]:>20s}{cols[2]:>23s}{cols[3]:>9s} | missing & heard by espeak / Telugu / either")
    for lab in GOLD_TYPES:
        c = funnel.get(lab)
        if not c:
            continue
        tot.update(c)
        print(f"{lab:19s}{c['gold']:>5d} | {c[cols[0]]:>25d}{c[cols[1]]:>20d}{c[cols[2]]:>23d}{c[cols[3]]:>9d} | "
              f"{c['  heard by espeak']:>3d} / {c['  heard by Telugu']:>3d} / {c['  heard by either']:>3d}")
    print(f"{'ALL':19s}{tot['gold']:>5d} | {tot[cols[0]]:>25d}{tot[cols[1]]:>20d}{tot[cols[2]]:>23d}{tot[cols[3]]:>9d} | "
          f"{tot['  heard by espeak']:>3d} / {tot['  heard by Telugu']:>3d} / {tot['  heard by either']:>3d}")
    print("\nwords of the written-but-not-tagged tokens:")
    for lab in GOLD_TYPES:
        if untagged.get(lab):
            print(f"  {lab:19s} " + ", ".join(f"{w} x{n}" for w, n in untagged[lab].most_common(a.examples)))
    if ceil:
        print("\nthe model's slot F1 per type on the same part with perfect inputs vs real recognizer phones (gold transcript):")
        print(f"  {'type':19s}{'gold units':>11s}{'perfect inputs':>16s}{'real phones':>13s}")
        for lab in GOLD_TYPES:
            p, q = ceil["nptel_g2p_clean"].get(lab), ceil["nptel_recognized"].get(lab)
            if p and p["support"]:
                print(f"  {lab:19s}{p['support']:>11d}{p['f1']:>16.2f}{(q['f1'] if q else 0):>13.2f}")
    if a.out:
        Path(a.out).write_text(json.dumps({"funnel": {k: dict(v) for k, v in funnel.items()},
                                           "untagged_words": {k: dict(v) for k, v in untagged.items()}, "perfect_vs_real": ceil}, indent=2))


if __name__ == "__main__":
    main()
