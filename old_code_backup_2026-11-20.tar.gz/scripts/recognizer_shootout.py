#!/usr/bin/env python
"""Does a CTC recognizer write anything where the speaker says "uh"?

Runs candidate recognizers over the aligned segments of a verified NPTEL lecture (same segments and padding as
scripts/nptel_phones.py) and measures, against the forced-aligned gold tokens:
  * "uh" spans: how many get any token, and how many get a *vowel* token (a consonant is usually a neighbour's);
  * fluent words: how many get any token (a recognizer that is just silent would also "miss" fewer uh's by being noisy);
  * long pauses between words (>= 0.4 s): how many contain a token (false alarms).
Each part of the lecture (first 60% = the part a noise profile would be fitted on, last 40% = held out) is reported.
Recognitions are cached in data/nptel/recognizers/<name>.jsonl (same format as data/nptel/phones/*.jsonl).

Run: HF_HOME=.cache/hf HF_HUB_OFFLINE=1 .venv/bin/python -I scripts/recognizer_shootout.py --models current,vakyansh-te
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nptel.recognized import load_recognized, split_tokens  # noqa: E402
from pipeline.charrec import greedy_tokens  # noqa: E402
from nptel.rsml import aligned_to_side, parse_aligned  # noqa: E402

# name -> how to run it. "script" decides what counts as a vowel token.
MODELS = {
    "current": dict(repo="facebook/wav2vec2-xlsr-53-espeak-cv-ft", script="ipa", cached=ROOT / "data/nptel/phones/english_001.jsonl"),
    "vakyansh-te": dict(repo="Harveenchadha/vakyansh-wav2vec2-telugu-tem-100", script="tel"),
    "xlsr53-te": dict(repo="anuragshas/wav2vec2-large-xlsr-53-telugu", script="tel"),
    "mms-tel": dict(repo="facebook/mms-1b-all", lang="tel", script="tel"),
    "mms-eng": dict(repo="facebook/mms-1b-all", lang="eng", script="latin"),
}
IPA_VOWELS = set("aeiouyɐəɛɪʊʌɑɔæɜɨʉɯɤøœɶɒɘɵɞɚ")


def is_vowel(tok: str, script: str) -> bool:
    if script == "ipa":
        return any(c in IPA_VOWELS for c in tok)
    if script == "latin":
        return any(c in "aeiou" for c in tok.lower())
    if script == "tel":                                  # independent vowels, vowel signs, anusvara
        return any(0x0C02 <= ord(c) <= 0x0C14 or 0x0C3E <= ord(c) <= 0x0C4C or ord(c) in (0x0C55, 0x0C56) for c in tok)
    raise ValueError(script)


def recognize(name: str, spec: dict, aligned: Path, wav: Path, pad: float, limit: int, device: str) -> Path:
    """Greedy CTC over every aligned segment; writes data/nptel/recognizers/<name>.jsonl (cached)."""
    out = ROOT / "data/nptel/recognizers" / (f"{name}.partial.jsonl" if limit else f"{name}.jsonl")   # a smoke run never poses as the cache
    if spec.get("cached"):
        return spec["cached"]
    if out.exists() and not limit:
        return out
    import numpy as np
    import torch
    from transformers import AutoFeatureExtractor, AutoTokenizer, Wav2Vec2ForCTC

    from pipeline.audio import read_wav

    kw = {"target_lang": spec["lang"], "ignore_mismatched_sizes": True} if spec.get("lang") else {}
    fe = AutoFeatureExtractor.from_pretrained(spec["repo"])
    tok = AutoTokenizer.from_pretrained(spec["repo"], **({"target_lang": spec["lang"]} if spec.get("lang") else {}))
    model = Wav2Vec2ForCTC.from_pretrained(spec["repo"], **kw).to(device).eval()
    vocab = {i: t for t, i in tok.get_vocab().items()}
    blank = tok.pad_token_id
    print(f"[{name}] {spec['repo']} loaded; vocab {len(vocab)}, blank id {blank} ({vocab.get(blank)!r}), device {device}", flush=True)
    x = read_wav(wav)
    segs = parse_aligned(aligned)[:limit or None]
    out.parent.mkdir(parents=True, exist_ok=True)
    t0, n = time.time(), 0
    with open(out, "w") as fh, torch.no_grad():
        for k, aseg in enumerate(segs):
            s0, s1 = max(0.0, aseg.seg.start - pad), min(len(x) / 16000, aseg.seg.end + pad)
            inp = fe(x[int(s0 * 16000):int(s1 * 16000)], sampling_rate=16000, return_tensors="pt")
            probs = model(inp.input_values.to(device)).logits[0].float().softmax(-1)
            ids, pmax = probs.argmax(-1).cpu().numpy(), probs.max(-1).values.cpu().numpy()
            toks = greedy_tokens(ids, pmax, vocab, blank, s0)
            n += len(toks)
            fh.write(json.dumps({"seg": aseg.seg.idx, "t0": round(s0, 3), "t1": round(s1, 3), "tokens": toks}) + "\n")
            if (k + 1) % 50 == 0:
                print(f"[{name}]   {k + 1}/{len(segs)} segments, {n} tokens, {time.time() - t0:.0f}s", flush=True)
    print(f"[{name}] wrote {out}: {n} tokens in {time.time() - t0:.0f}s", flush=True)
    return out


def measure(toks: list[dict], rec_path: Path, script: str) -> dict:
    """Per lecture part: uh coverage, fluent-word coverage, false alarms in long pauses."""
    import bisect
    centres, rtoks = load_recognized(rec_path)

    def inside(t0: float, t1: float) -> list[str]:
        return [t["tok"] for t in rtoks[bisect.bisect_left(centres, t0):bisect.bisect_right(centres, t1)]]

    cut = split_tokens(toks, 0.6)
    res = {}
    for part, sub in (("fit", toks[:cut]), ("held-out", toks[cut:])):
        uh = [t for t in sub if t["label"] == "FILLER_HESITATION" and t["spoken"].lower() == "uh"]
        fl = [t for t in sub if t["label"] == "O" and t["end"] - t["start"] >= 0.1]
        n_any = n_vow = n_near = 0
        for t in uh:
            got = inside(t["start"], t["end"])
            n_any += bool(got)
            n_vow += any(is_vowel(g, script) for g in got)
            n_near += any(is_vowel(g, script) for g in inside(t["start"] - 0.1, t["end"] + 0.1))
        fl_any = sum(bool(inside(t["start"], t["end"])) for t in fl)
        gaps = [(a["end"] + 0.05, b["start"] - 0.05) for a, b in zip(sub, sub[1:]) if b["start"] - a["end"] >= 0.4]
        g_tok = [inside(s, e) for s, e in gaps]
        res[part] = {"uh": len(uh), "uh_any_token": n_any, "uh_vowel_token": n_vow, "uh_vowel_within_100ms": n_near,
                     "fluent_words": len(fl), "fluent_any_token": fl_any, "pauses_ge_0.4s": len(gaps),
                     "pauses_with_token": sum(bool(g) for g in g_tok),
                     "pauses_with_vowel": sum(any(is_vowel(t, script) for t in g) for g in g_tok)}
    return res


def show(name: str, r: dict) -> None:
    for part, m in r.items():
        print(f"{name:12s} {part:9s} uh: any token {m['uh_any_token']:>3d}/{m['uh']:<3d} ({m['uh_any_token'] / max(1, m['uh']):4.0%})  "
              f"vowel {m['uh_vowel_token']:>3d} ({m['uh_vowel_token'] / max(1, m['uh']):4.0%})  vowel±100ms {m['uh_vowel_within_100ms'] / max(1, m['uh']):4.0%}"
              f" | fluent words with a token {m['fluent_any_token'] / max(1, m['fluent_words']):4.0%}"
              f" | pauses ≥0.4s with a token {m['pauses_with_token']:>3d}/{m['pauses_ge_0.4s']:<3d} ({m['pauses_with_token'] / max(1, m['pauses_ge_0.4s']):4.0%})"
              f", with a vowel {m['pauses_with_vowel'] / max(1, m['pauses_ge_0.4s']):4.0%}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="current", help=f"comma-separated, from {list(MODELS)}")
    ap.add_argument("--aligned", default=str(ROOT / "data/nptel/raw/english_001/english_001.aligned.rsml"))
    ap.add_argument("--wav", default=str(ROOT / "data/nptel/wav16k/english_001.wav"))
    ap.add_argument("--pad", type=float, default=0.3)
    ap.add_argument("--limit", type=int, default=0, help="only the first N segments (smoke test; not cached)")
    ap.add_argument("--device", default="mps")
    ap.add_argument("--examples", type=int, default=0, help="print the tokens each model wrote for the first N uh spans")
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    toks = aligned_to_side(Path(a.aligned), sid="gold")["tokens"]
    results, paths = {}, {}
    for name in a.models.split(","):
        spec = MODELS[name]
        paths[name] = recognize(name, spec, Path(a.aligned), Path(a.wav), a.pad, a.limit, a.device)
        results[name] = measure(toks, paths[name], spec["script"])
        show(name, results[name])
    if a.examples:
        import bisect
        loaded = {n: load_recognized(p) for n, p in paths.items()}
        uh = [t for t in toks if t["label"] == "FILLER_HESITATION" and t["spoken"].lower() == "uh"][:a.examples]
        print("\nwhat each model wrote inside the first uh spans (∅ = nothing):")
        for t in uh:
            row = []
            for n, (c, r) in loaded.items():
                got = [x["tok"] for x in r[bisect.bisect_left(c, t["start"]):bisect.bisect_right(c, t["end"])]]
                row.append(f"{n}: {''.join(got) or '∅'}")
            print(f"  {t['start']:7.2f}s  " + "   ".join(row))
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
