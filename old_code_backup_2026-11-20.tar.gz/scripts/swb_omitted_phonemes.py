#!/usr/bin/env python
"""Omitted phonemes on Switchboard: are the disfluencies found in them?

The Switchboard release has no audio and no phone-level transcription, only word transcripts and the pronunciation
lexicon. So, per utterance:
  * the phone sequence *including the disfluencies* ("what was said") is the lexicon phones of every spoken token; the
    owner token of every phone is known. It is used exactly, and also corrupted by a simulated recognizer
    (``phones.noise.PhoneNoise``: deletions, substitutions between similar phones, insertions) at several strengths;
  * the G2P of the transcript *ignoring the disfluencies* is the lexicon phones of the fluent tokens only.
The two are aligned (Levenshtein, phone level). The phones of the first sequence that no G2P phone is aligned to are
the OMITTED phonemes. Reported per noise level:
  * omission percentage: omitted phonemes / phones of the sequence;
  * what the omitted phonemes are (from the known owner): phones of disfluent tokens, phones of fluent tokens
    (misaligned), or inserted noise;
  * how much of the disfluent tokens' phones lies in the omitted phonemes, and which disfluent tokens are found
    (at least half of their surviving phones omitted), absorbed into the transcript's G2P, or lost (all their phones
    deleted by the noise), per type.
No timing and no audio: the noise is a simulation, not a measured recognizer.

Run: .venv/bin/python -I scripts/swb_omitted_phonemes.py            # all 4,876 sides (a few minutes per noise level)
"""
from __future__ import annotations

import argparse
import gzip
import itertools
import json
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from model.seq import _g2p, _skeleton_word  # noqa: E402
from phones.lexicon import Lexicon  # noqa: E402
from phones.noise import PhoneNoise  # noqa: E402
from pipeline.score import GOLD_TYPES, align_idx  # noqa: E402

FOUND = "found in the omitted phonemes"
ABSORBED = "absorbed by the transcript's G2P"
LOST = "lost (all phones deleted by the noise)"


def level_name(p: tuple[float, float, float]) -> str:
    return "exact (no noise)" if not any(p) else f"noise del/sub/ins {p[0]:.0%}/{p[1]:.0%}/{p[2]:.0%}"


def run(sides, lex: Lexicon, levels: list[tuple[float, float, float]], seed: int) -> dict:
    noises = [PhoneNoise(p_del=d, p_sub=s, p_ins=i, seed=seed) for d, s, i in levels]
    tot = [{"phones": 0, "omitted": 0, "omitted_by": Counter(), "d_phones": 0, "d_omitted": 0, "fate": Counter(), "by_type": {},
            "type_phones": Counter()} for _ in levels]
    n_utt = n_tok = 0
    t0 = time.time()
    for si, side in enumerate(sides):
        for _, grp in itertools.groupby(side["tokens"], key=lambda t: t["utt"]):
            toks = [t for t in grp if t["label"] != "NOISE" and t.get("phones")]
            if not toks:
                continue
            n_utt += 1
            n_tok += len(toks)
            A, owner = [], []
            for ti, t in enumerate(toks):
                A += t["phones"]
                owner += [ti] * len(t["phones"])
            is_d = [t["label"] in GOLD_TYPES for t in toks]
            B = [p for t, d in zip(toks, is_d) if not d for p in _g2p(lex, _skeleton_word(t), t["phones"])]
            for lv, noise in enumerate(noises):
                T = tot[lv]
                noisy, src = noise.corrupt_idx(A)
                own = [-1 if (k and src[k] == src[k - 1]) else owner[src[k]] for k in range(len(noisy))]     # -1: an inserted phone
                omitted = {j for i, j in align_idx(B, noisy) if i is None}
                T["phones"] += len(noisy)
                T["omitted"] += len(omitted)
                for j in omitted:
                    o = own[j]
                    T["omitted_by"]["inserted noise" if o < 0 else "disfluent token" if is_d[o] else "fluent token"] += 1
                per_tok: dict[int, list[int]] = {}
                for j, o in enumerate(own):
                    if o >= 0 and is_d[o]:
                        per_tok.setdefault(o, []).append(j)
                        T["d_phones"] += 1
                        T["d_omitted"] += j in omitted
                for ti, t in enumerate(toks):
                    if not is_d[ti]:
                        continue
                    T["type_phones"][t["label"]] += len(t["phones"])
                    js = per_tok.get(ti, [])
                    fate = LOST if not js else (FOUND if sum(j in omitted for j in js) / len(js) >= 0.5 else ABSORBED)
                    T["fate"][fate] += 1
                    T["by_type"].setdefault(t["label"], Counter())[fate] += 1
        if (si + 1) % 500 == 0:
            print(f"  {si + 1} sides, {n_utt} utterances, {time.time() - t0:.0f}s", flush=True)
    return {"utterances": n_utt, "tokens": n_tok, "levels": [
        {"level": level_name(p), "phones": T["phones"], "omitted": T["omitted"], "omitted_by": dict(T["omitted_by"]),
         "disfluent_phones": T["d_phones"], "disfluent_phones_omitted": T["d_omitted"], "token_fate": dict(T["fate"]),
         "by_type": {k: dict(v) for k, v in T["by_type"].items()}, "type_phones": dict(T["type_phones"])}
        for p, T in zip(levels, tot)]}


def show(res: dict) -> None:
    print(f"\n{res['utterances']} utterances, {res['tokens']} tokens\n")
    print(f"{'phone sequence':28s}{'phones':>10s}{'omitted phonemes':>20s}   what the omitted phonemes are: "
          f"{'disfluent token':>16s}{'fluent token':>14s}{'inserted noise':>16s}  | disfluent phones in the omitted ones")
    for L in res["levels"]:
        n, om, by = L["phones"], L["omitted"], L["omitted_by"]
        f = lambda k: by.get(k, 0) / max(1, om)                                                    # noqa: E731
        print(f"{L['level']:28s}{n:>10d}{om:>12d} = {om / n:>5.1%}   {'':30s}{f('disfluent token'):>6.1%}{f('fluent token'):>14.1%}{f('inserted noise'):>16.1%}"
              f"  | {L['disfluent_phones_omitted']}/{L['disfluent_phones']} = {L['disfluent_phones_omitted'] / max(1, L['disfluent_phones']):.1%}")
    print("\ngold disfluent tokens by what happens to them (found = at least half of their surviving phones are omitted phonemes):")
    print(f"{'phone sequence':28s}{'tokens':>10s}{FOUND:>34s}{ABSORBED:>34s}{LOST:>40s}")
    for L in res["levels"]:
        tf = L["token_fate"]
        k = sum(tf.values())
        print(f"{L['level']:28s}{k:>10d}" + "".join(f"{tf.get(x, 0):>{w - 8}d} = {tf.get(x, 0) / k:>5.1%}" for x, w in ((FOUND, 34), (ABSORBED, 34), (LOST, 40))))
    for idx in (0, 2):
        if idx < len(res["levels"]):
            L = res["levels"][idx]
            print(f"\nper type, {L['level']}:")
            print(f"  {'type':20s}{'tokens':>9s}{'share of all phones':>21s}{'found':>10s}{'absorbed':>10s}{'lost':>8s}")
            for lab in GOLD_TYPES:
                c = L["by_type"].get(lab)
                if c:
                    k = sum(c.values())
                    print(f"  {lab:20s}{k:>9d}{L['type_phones'].get(lab, 0) / L['phones']:>21.2%}"
                          f"{c.get(FOUND, 0) / k:>10.1%}{c.get(ABSORBED, 0) / k:>10.1%}{c.get(LOST, 0) / k:>8.1%}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--inp", default=str(ROOT / "data/processed/swb_tokens.jsonl.gz"))
    ap.add_argument("--lex", default=str(ROOT / "data/raw/switchboard_ms98/sw-ms98-dict.text"))
    ap.add_argument("--sides", type=int, default=0, help="only the first N sides (0 = all 4,876)")
    ap.add_argument("--levels", default="0:0:0,0.04:0.07:0.02,0.08:0.14:0.04,0.16:0.28:0.08",
                    help="del:sub:ins rates of the simulated recognizer, comma separated; 0:0:0 = exact")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default=str(ROOT / "results/swb_omitted_phonemes.json"))
    a = ap.parse_args()

    levels = [tuple(float(x) for x in s.split(":")) for s in a.levels.split(",")]
    lex = Lexicon.from_file(a.lex)
    with gzip.open(a.inp, "rt", encoding="utf-8") as fh:
        sides = [json.loads(line) for line in itertools.islice(fh, a.sides or None)]
    print(f"{len(sides)} sides")
    res = run(sides, lex, levels, a.seed)
    show(res)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(res, indent=2))
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
