#!/usr/bin/env python
"""How good is a recognizer as a *phone stream*, and do two recognizers hear the same "uh"s?

Each recognizer's output on the aligned lecture (data/nptel/phones or data/nptel/recognizers, see
scripts/recognizer_shootout.py) is mapped to Switchboard phones (IPA map for the espeak recognizer, Telugu script map
for the Telugu one) and aligned per utterance with the G2P phones of the gold tokens, exactly as in
scripts/calibrate_noise.py. Reports error rates of the words that were recognized at all, whole-word drops, and for the
one-phone "uh": how often a vowel is written, by either recognizer alone and by at least one of two.

Run: HF_HOME=.cache/hf HF_HUB_OFFLINE=1 .venv/bin/python -I scripts/recognizer_phone_quality.py
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from calibrate_noise import summarize  # noqa: E402
from nptel.recognized import split_tokens  # noqa: E402
from nptel.streams import phone_stream, phones_between, utterance_rows  # noqa: E402
from nptel.rsml import aligned_to_side  # noqa: E402
from phones.channel import HES, HES_REF, VOWELS  # noqa: E402
from phones.g2p import G2P  # noqa: E402

SOURCES = {
    "current (espeak XLSR-53)": (ROOT / "data/nptel/phones/english_001.jsonl", "ipa"),
    "xlsr53-te (Telugu script)": (ROOT / "data/nptel/recognizers/xlsr53-te.jsonl", "tel"),
}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--aligned", default=str(ROOT / "data/nptel/raw/english_001/english_001.aligned.rsml"))
    ap.add_argument("--lex", default=str(ROOT / "data/raw/switchboard_ms98/sw-ms98-dict.text"))
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    g2p = G2P.from_files(a.lex, ROOT / "configs/phonemap.yaml")
    toks = aligned_to_side(Path(a.aligned), sid="gold")["tokens"]
    cut = split_tokens(toks, 0.6)
    streams = {n: phone_stream(p, k, g2p.ipa) for n, (p, k) in SOURCES.items()}
    results: dict = {}
    for name, (centres, phones) in streams.items():
        results[name] = {}
        for part, sub in (("fit", toks[:cut]), ("held-out", toks[cut:])):
            s = summarize(utterance_rows(sub, g2p, (centres, phones)))
            results[name][part] = s
            print(f"{name:27s} {part:9s} words dropped (1/2/3+ phones) {s['token_dropped']['1']} | {s['token_dropped']['2']} | {s['token_dropped']['3+']}"
                  f"  | phones of recognized words: deleted {s['on_surviving_tokens'].get('del', 0):.1%} substituted {s['on_surviving_tokens'].get('sub', 0):.1%}"
                  f" (error {s['on_surviving_tokens'].get('del+sub', 0):.1%})  | strays/100 words {s['inserted_phones_per_100_tokens']}")
            h = s["hesitations"]
            print(f"{'':27s} {'':9s} 'uh' not written as a vowel: {h['not_written_as_a_vowel']:.1%} of {h['n']}   written as {h['written_as']}")

    # does either recognizer write a vowel in the span of the same "uh"? (the span itself, as in the shootout)
    print("\n'uh' spans with a vowel phone, by recognizer and combined:")
    names = list(streams)
    for part, sub in (("fit", toks[:cut]), ("held-out", toks[cut:])):
        uh = [t for t in sub if t["label"] == HES and tuple(g2p.phones(t["spoken"])) == HES_REF]
        hit = {n: [any(p in VOWELS for p in phones_between(streams[n], t["start"], t["end"]))
                   for t in uh] for n in names}
        either = [any(h[i] for h in hit.values()) for i in range(len(uh))]
        both = [all(h[i] for h in hit.values()) for i in range(len(uh))]
        print(f"  {part:9s} n={len(uh):3d}  " + "  ".join(f"{n.split()[0]} {sum(h)}/{len(uh)} ({sum(h) / len(uh):.0%})" for n, h in hit.items())
              + f"  either {sum(either)} ({sum(either) / len(uh):.0%})  both {sum(both)}")
        results.setdefault("uh_vowel", {})[part] = {"n": len(uh), **{n: sum(h) for n, h in hit.items()}, "either": sum(either), "both": sum(both)}
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
