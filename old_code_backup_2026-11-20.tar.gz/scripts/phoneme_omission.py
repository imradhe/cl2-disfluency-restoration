#!/usr/bin/env python
"""Phoneme omission: how many of the phones that were really said does the transcript's G2P leave out, and are the
omitted phones a real signal of disfluencies?

Per utterance of a forced-aligned, human-verified lecture, two phone sequences are aligned (Levenshtein, phone level):
  * the *recognized* phones: what a phone recognizer heard in the utterance's time span. Everything said is in it,
    disfluencies included;
  * the G2P phones of the transcript under two conditions:
      "verbatim"  every spoken token, disfluent ones too  -> what is left over is recognizer error only (the control);
      "fluent"    the transcript an ASR gives: disfluent tokens ignored -> what is left over also contains the
                  disfluencies;
      "whisper"   the words Whisper really wrote (fillers respelled as in the pipeline), which keep many of the
                  disfluent words -> how much of the signal survives with a real transcript.
Two omission percentages per condition:
  * recognized phones left out by the G2P (aligned to nothing in it) / recognized phones: the share of what was said
    that the transcript does not account for;
  * G2P phones left out of the recognized sequence / G2P phones: expected phones the recognizer did not write.
Signal test: every recognized phone is located by its centre time in the gold token spans (disfluent token / fluent
token / gap). If the phones the fluent G2P leaves out were only recognizer noise they would be as frequent in disfluent
spans as in fluent ones; the verbatim control shows what noise alone does. Odds ratio with a bootstrap over utterances.

Run: HF_HOME=.cache/hf HF_HUB_OFFLINE=1 .venv/bin/python -I scripts/phoneme_omission.py
"""
from __future__ import annotations

import argparse
import bisect
import itertools
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nptel.rsml import aligned_to_side  # noqa: E402
from nptel.streams import phone_stream  # noqa: E402
from phones.g2p import G2P  # noqa: E402
from pipeline.asr import norm_word, normalize_fillers, Word  # noqa: E402
from pipeline.score import GOLD_TYPES, align_idx  # noqa: E402

SOURCES = {"espeak recognizer (current)": (ROOT / "data/nptel/phones/english_001.jsonl", "ipa"),
           "Telugu recognizer": (ROOT / "data/nptel/recognizers/xlsr53-te.jsonl", "tel")}
CONDS = ("verbatim", "fluent", "whisper")


def g2p_of(t: dict, g2p: G2P) -> list[str]:
    word = t["intended"] if t["label"] == "MISPRONUNCIATION" and t["intended"] else t["spoken"]
    return list(g2p.phones(word))


def utterance_counts(grp: list[dict], g2p: G2P, stream: tuple[list[float], list[str]], asr: list[tuple[str, float]]) -> dict | None:
    """Alignment counts of one utterance under both G2P conditions, plus the span class of every recognized phone."""
    toks = [t for t in grp if t["label"] != "NOISE"]
    if not toks:
        return None
    centres, phones = stream
    lo, hi = bisect.bisect_left(centres, toks[0]["start"]), bisect.bisect_right(centres, toks[-1]["end"])
    hyp, hc = phones[lo:hi], centres[lo:hi]
    starts, ends = [t["start"] for t in toks], [t["end"] for t in toks]
    cls = []                                                      # D = inside a disfluent token, F = inside a fluent one
    for c in hc:
        k = bisect.bisect_right(starts, c) - 1
        cls.append("G" if k < 0 or c > ends[k] else ("D" if toks[k]["label"] in GOLD_TYPES else "F"))
    out = {"n_hyp": len(hyp), "n_D_tokens": sum(t["label"] in GOLD_TYPES for t in toks),
           "span_phones": {c: cls.count(c) for c in "DFG"}}
    for cond in CONDS:
        if cond == "whisper":                                       # Whisper's own words of this utterance, by word centre
            a, b = bisect.bisect_left([c for _, c in asr], toks[0]["start"]), bisect.bisect_right([c for _, c in asr], toks[-1]["end"])
            ref = [p for w, _ in asr[a:b] for p in g2p.phones(w)]
        else:
            ref = [p for t in toks if cond == "verbatim" or t["label"] not in GOLD_TYPES for p in g2p_of(t, g2p)]
        ops = align_idx(ref, hyp)
        extra = [j for i, j in ops if i is None]                    # recognized phones the G2P does not account for
        out[cond] = {"n_ref": len(ref), "omitted_from_recognized": sum(j is None for _, j in ops),
                     "sub": sum(i is not None and j is not None and ref[i] != hyp[j] for i, j in ops),
                     "unexplained": len(extra),
                     "unexplained_by_span": {c: sum(cls[j] == c for j in extra) for c in "DFG"}}
        out[cond]["D_token_hits"] = []                              # per disfluent token: (label, recognized phones in span, unexplained in span)
        ex = set(extra)
        for ti, t in enumerate(toks):
            if t["label"] in GOLD_TYPES:
                js = [j for j, c in enumerate(hc) if t["start"] <= c <= t["end"]]
                out[cond]["D_token_hits"].append((t["label"], len(js), sum(j in ex for j in js)))
    return out


def odds_ratio(a: float, n_a: float, b: float, n_b: float) -> float:
    """Odds of 'unexplained' in class A over class B (0.5 added to every cell)."""
    return ((a + .5) / (n_a - a + .5)) / ((b + .5) / (n_b - b + .5))


def spearman(x: np.ndarray, y: np.ndarray) -> float:
    def rank(v):
        order = v.argsort(kind="mergesort")
        r = np.empty(len(v))
        r[order] = np.arange(len(v))
        for val in np.unique(v):                                    # average ranks for ties
            m = v == val
            r[m] = r[m].mean()
        return r
    rx, ry = rank(x), rank(y)
    return float(np.corrcoef(rx, ry)[0, 1]) if rx.std() and ry.std() else 0.0


def report(name: str, utts: list[dict], boots: int, seed: int = 0) -> dict:
    res: dict = {}
    n_hyp = sum(u["n_hyp"] for u in utts)
    print(f"\n=== {name}   ({len(utts)} utterances, {n_hyp} recognized phones)")
    print(f"{'G2P condition':34s}{'G2P phones':>11s}{'omitted from recognized':>26s}{'recognized phones not in G2P':>30s}{'substituted':>13s}")
    for cond in CONDS:
        n_ref = sum(u[cond]["n_ref"] for u in utts)
        om, ex, sub = (sum(u[cond][k] for u in utts) for k in ("omitted_from_recognized", "unexplained", "sub"))
        label = {"verbatim": "verbatim (disfluencies included)", "fluent": "fluent (disfluencies ignored)",
                 "whisper": "Whisper's words (the real ASR)"}[cond]
        print(f"{label:34s}{n_ref:>11d}{om:>14d} = {om / n_ref:>6.1%}{ex:>17d} = {ex / n_hyp:>6.1%}{sub / n_ref:>13.1%}")
        res[cond] = {"g2p_phones": n_ref, "omitted_from_recognized": om, "omitted_pct": om / n_ref, "recognized_not_in_g2p": ex,
                     "recognized_not_in_g2p_pct": ex / n_hyp, "substituted_pct": sub / n_ref}

    print("\nwhere do the recognized phones that the G2P leaves out fall? (by gold token span of the phone's centre)")
    print(f"{'G2P condition':34s}{'in disfluent spans':>22s}{'in fluent spans':>20s}{'in gaps':>16s}{'odds ratio D vs F':>20s}{'95% CI':>20s}")
    rng = np.random.default_rng(seed)
    n = len(utts)
    for cond in CONDS:
        ex = np.array([[u[cond]["unexplained_by_span"][c] for c in "DFG"] for u in utts], dtype=float)
        tot = np.array([[u["span_phones"][c] for c in "DFG"] for u in utts], dtype=float)
        s, t = ex.sum(0), tot.sum(0)
        orr = odds_ratio(s[0], t[0], s[1], t[1])
        bs = []
        for _ in range(boots):
            i = rng.integers(0, n, n)
            ss, tt = ex[i].sum(0), tot[i].sum(0)
            bs.append(odds_ratio(ss[0], tt[0], ss[1], tt[1]))
        lo, hi = np.percentile(bs, [2.5, 97.5])
        label = {"verbatim": "verbatim (control: noise only)", "fluent": "fluent (disfluencies ignored)",
                 "whisper": "Whisper's words (the real ASR)"}[cond]
        print(f"{label:34s}{int(s[0]):>8d}/{int(t[0]):<5d}={s[0] / t[0]:>5.1%}{int(s[1]):>9d}/{int(t[1]):<6d}={s[1] / t[1]:>5.1%}"
              f"{int(s[2]):>6d}/{int(t[2]):<4d}={s[2] / max(1, t[2]):>5.1%}{orr:>12.1f}{'[%.1f, %.1f]' % (lo, hi):>22s}")
        res[cond]["by_span"] = {c: {"unexplained": int(a), "phones": int(b)} for c, a, b in zip("DFG", s, t)}
        res[cond]["odds_ratio_D_vs_F"] = {"value": orr, "ci95": [float(lo), float(hi)]}
        if cond in ("fluent", "whisper"):
            share_d = s[0] / s.sum()
            print(f"{'':34s}-> {share_d:.0%} of the unexplained phones lie in disfluent spans, which hold "
                  f"{t[0] / t.sum():.0%} of all recognized phones; {s[0] / t[0]:.0%} of the phones in disfluent spans are unexplained")
            res[cond]["share_of_unexplained_in_D"] = float(share_d)
            res[cond]["share_of_D_phones_unexplained"] = float(s[0] / t[0])
            res[cond]["share_of_all_phones_in_D"] = float(t[0] / t.sum())

    print("\nper disfluency type: disfluent tokens with at least one recognized phone / with at least one unexplained phone")
    per: dict[str, list] = defaultdict(list)
    per_w: dict[str, list] = defaultdict(list)
    for u in utts:
        for lab, nph, nex in u["fluent"]["D_token_hits"]:
            per[lab].append((nph, nex))
        for lab, nph, nex in u["whisper"]["D_token_hits"]:
            per_w[lab].append((nph, nex))
    print(f"{'type':20s}{'tokens':>8s}{'any recognized phone':>23s}{'any unexplained phone':>25s}{'(vs Whisper words)':>22s}")
    res["per_type"] = {}
    for lab in GOLD_TYPES:
        v = per.get(lab)
        if v:
            k = len(v)
            a, b = sum(p > 0 for p, _ in v), sum(e > 0 for _, e in v)
            c = sum(e > 0 for _, e in per_w[lab])
            print(f"{lab:20s}{k:>8d}{a:>14d} = {a / k:>5.0%}{b:>16d} = {b / k:>5.0%}{c:>14d} = {c / k:>5.0%}")
            res["per_type"][lab] = {"tokens": k, "any_phone": a, "any_unexplained": b, "any_unexplained_vs_whisper": c}

    d_count = np.array([u["n_D_tokens"] for u in utts], dtype=float)
    res["spearman_utterance"] = {}
    for cond in CONDS:
        ex = np.array([u[cond]["unexplained"] for u in utts], dtype=float)
        res["spearman_utterance"][cond] = spearman(d_count, ex)
    print(f"\nper utterance, Spearman correlation between the number of gold disfluent tokens and the number of recognized "
          f"phones the G2P leaves out: fluent {res['spearman_utterance']['fluent']:.2f}, Whisper words {res['spearman_utterance']['whisper']:.2f}, "
          f"verbatim control {res['spearman_utterance']['verbatim']:.2f}")
    return res


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--aligned", default=str(ROOT / "data/nptel/raw/english_001/english_001.aligned.rsml"))
    ap.add_argument("--lex", default=str(ROOT / "data/raw/switchboard_ms98/sw-ms98-dict.text"))
    ap.add_argument("--asr", default=str(ROOT / "results/pipeline/english_001/asr_mlx_community_whisper_large_v3_turbo_1937s.json"),
                    help="Whisper words of the lecture (cached by scripts/run_pipeline.py)")
    ap.add_argument("--boots", type=int, default=2000)
    ap.add_argument("--out", default=str(ROOT / "results/phoneme_omission.json"))
    a = ap.parse_args()

    g2p = G2P.from_files(a.lex, ROOT / "configs/phonemap.yaml")
    toks = aligned_to_side(Path(a.aligned), sid="gold")["tokens"]
    n_d = sum(t["label"] in GOLD_TYPES for t in toks)
    print(f"lecture: {len(toks)} tokens, {n_d} disfluent ({n_d / len(toks):.1%}): "
          f"{dict(Counter(t['label'] for t in toks if t['label'] in GOLD_TYPES))}")
    groups = [list(g) for _, g in itertools.groupby(toks, key=lambda t: t["utt"])]
    asr_json = json.loads(Path(a.asr).read_text())
    words = [Word(w["text"], w["start"], w["end"], w["prob"]) for ws in asr_json for w in ws]
    words, _ = normalize_fillers([w for w in words if norm_word(w.text)])
    asr = [(norm_word(w.text), (w.start + w.end) / 2) for w in words]
    results = {}
    for name, (path, kind) in SOURCES.items():
        stream = phone_stream(path, kind, g2p.ipa)
        utts = [u for u in (utterance_counts(g, g2p, stream, asr) for g in groups) if u]
        results[name] = report(name, utts, a.boots)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(results, indent=2, default=float))
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
