#!/usr/bin/env python
"""Are the disfluencies found in the omitted phonemes?  (sequence test, no timing inside an utterance)

Per utterance, with P = the phones a recognizer heard (everything said, disfluencies included):
  1. align the G2P of the transcript *ignoring the disfluencies* with P: the phones of P that no G2P phone is aligned
     to are the OMITTED phonemes (the transcript omits them);
  2. align the G2P of the transcript *including the disfluencies* with P, remembering which token every G2P phone
     comes from: every phone of P is now explained by a disfluent token, by a fluent token, or by nothing.
Then
  * what the omitted phonemes are: the share explained by disfluent tokens (the disfluencies found in them), by
    fluent tokens (the alignment explains the phone twice differently: substitutions, shifts), or by nothing (noise);
  * which disfluent tokens are found: those whose phones in P are mostly omitted phonemes; the others were either not
    heard at all or were absorbed into the transcript's G2P.
"Transcript" is the gold transcript with the disfluent tokens removed (ASR as it should be), or Whisper's real words.
The timing of the forced alignment only cuts the lecture into utterances.

Run: HF_HOME=.cache/hf HF_HUB_OFFLINE=1 .venv/bin/python -I scripts/omitted_phonemes.py
"""
from __future__ import annotations

import argparse
import bisect
import itertools
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nptel.rsml import aligned_to_side  # noqa: E402
from nptel.streams import phone_stream  # noqa: E402
from phones.g2p import G2P  # noqa: E402
from pipeline.asr import Word, norm_word, normalize_fillers  # noqa: E402
from pipeline.score import GOLD_TYPES, align_idx  # noqa: E402

SOURCES = {"espeak recognizer (current)": (ROOT / "data/nptel/phones/english_001.jsonl", "ipa"),
           "Telugu recognizer": (ROOT / "data/nptel/recognizers/xlsr53-te.jsonl", "tel")}


def g2p_of(t: dict, g2p: G2P) -> list[str]:
    word = t["intended"] if t["label"] == "MISPRONUNCIATION" and t["intended"] else t["spoken"]
    return list(g2p.phones(word))


def analyse(groups: list[list[dict]], g2p: G2P, stream, asr: list[tuple[str, float]] | None, keep_examples: int):
    """Counts (and examples) over all utterances; ``asr`` None: the transcript is the gold one without disfluencies."""
    centres, phones = stream
    asr_c = [c for _, c in asr] if asr else []
    cross = Counter()                    # (explained-by in the verbatim alignment) of the omitted phonemes
    absorbed = Counter()                 # same for the phones the transcript G2P did account for
    token_fate = Counter()               # per disfluent token: found / absorbed / not heard
    by_type: dict[str, Counter] = {}
    n_phones = n_omitted = n_hyp_d = 0
    examples: list[tuple] = []
    for grp in groups:
        toks = [t for t in grp if t["label"] != "NOISE"]
        if not toks:
            continue
        lo, hi = bisect.bisect_left(centres, toks[0]["start"]), bisect.bisect_right(centres, toks[-1]["end"])
        P = phones[lo:hi]
        # verbatim G2P with the token every phone comes from
        ref_v, owner = [], []
        for ti, t in enumerate(toks):
            ph = g2p_of(t, g2p)
            ref_v += ph
            owner += [ti] * len(ph)
        # transcript G2P: gold without the disfluent tokens, or Whisper's words of the utterance
        if asr is None:
            ref_f = [p for t in toks if t["label"] not in GOLD_TYPES for p in g2p_of(t, g2p)]
        else:
            a, b = bisect.bisect_left(asr_c, toks[0]["start"]), bisect.bisect_right(asr_c, toks[-1]["end"])
            ref_f = [p for w, _ in asr[a:b] for p in g2p.phones(w)]
        omitted = {j for i, j in align_idx(ref_f, P) if i is None}
        explained_by = {j: owner[i] for i, j in align_idx(ref_v, P) if i is not None and j is not None}
        is_d = lambda j: j in explained_by and toks[explained_by[j]]["label"] in GOLD_TYPES      # noqa: E731
        n_phones += len(P)
        n_omitted += len(omitted)
        n_hyp_d += sum(is_d(j) for j in range(len(P)))
        for j in range(len(P)):
            kind = "disfluent token" if is_d(j) else ("fluent token" if j in explained_by else "nothing")
            (cross if j in omitted else absorbed)[kind] += 1
        for ti, t in enumerate(toks):
            if t["label"] not in GOLD_TYPES:
                continue
            js = [j for j, o in explained_by.items() if o == ti]
            fate = "not heard (no phone aligned to it)" if not js else (
                "found in the omitted phonemes (>= half of its phones)" if sum(j in omitted for j in js) / len(js) >= 0.5
                else "heard but absorbed by the transcript's G2P")
            token_fate[fate] += 1
            by_type.setdefault(t["label"], Counter())[fate] += 1
        if len(examples) < 400:
            runs = [list(g) for _, g in itertools.groupby(sorted(omitted), key=lambda j, c=itertools.count(): j - next(c))]
            for run in runs:
                owners = [toks[explained_by[j]] for j in run if j in explained_by]
                d = [o for o in owners if o["label"] in GOLD_TYPES]
                words = " ".join(t["spoken"] for t in toks if t["label"] not in GOLD_TYPES)
                examples.append((run, [P[j] for j in run], d, owners, ref_f and words))
    return {"phones": n_phones, "omitted": n_omitted, "omitted_by_verbatim": dict(cross), "accounted_by_verbatim": dict(absorbed),
            "disfluent_phones_in_P": n_hyp_d, "token_fate": dict(token_fate), "by_type": {k: dict(v) for k, v in by_type.items()}}, examples


def show(name: str, cond: str, r: dict) -> None:
    n, om, cross = r["phones"], r["omitted"], r["omitted_by_verbatim"]
    print(f"\n=== {name} | transcript = {cond}")
    print(f"recognized phones {n}; omitted phonemes (not accounted for by the transcript's G2P): {om} = {om / n:.1%}")
    print(f"  of the omitted phonemes, the verbatim G2P (disfluencies included) explains them as:")
    for k in ("disfluent token", "fluent token", "nothing"):
        print(f"      {k:16s}{cross.get(k, 0):>6d} = {cross.get(k, 0) / om:>6.1%}")
    d_total = r["disfluent_phones_in_P"]
    found = cross.get("disfluent token", 0)
    print(f"  recognized phones explained by disfluent tokens: {d_total} ({d_total / n:.1%} of all); "
          f"{found} of them ({found / max(1, d_total):.0%}) are omitted phonemes, {d_total - found} were absorbed into fluent words")
    tf = r["token_fate"]
    tot = sum(tf.values())
    print(f"  the {tot} gold disfluent tokens:")
    for k, v in sorted(tf.items(), key=lambda kv: -kv[1]):
        print(f"      {k:58s}{v:>5d} = {v / tot:>5.0%}")
    print(f"  {'type':20s}{'tokens':>7s}{'found in omitted':>18s}{'absorbed':>10s}{'not heard':>11s}")
    for lab in GOLD_TYPES:
        c = r["by_type"].get(lab)
        if c:
            k = sum(c.values())
            f_, a_, n_ = (c.get(x, 0) for x in ("found in the omitted phonemes (>= half of its phones)",
                                                 "heard but absorbed by the transcript's G2P", "not heard (no phone aligned to it)"))
            print(f"  {lab:20s}{k:>7d}{f_:>12d} = {f_ / k:>3.0%}{a_:>6d} = {a_ / k:>3.0%}{n_:>6d} = {n_ / k:>3.0%}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--aligned", default=str(ROOT / "data/nptel/raw/english_001/english_001.aligned.rsml"))
    ap.add_argument("--lex", default=str(ROOT / "data/raw/switchboard_ms98/sw-ms98-dict.text"))
    ap.add_argument("--asr", default=str(ROOT / "results/pipeline/english_001/asr_mlx_community_whisper_large_v3_turbo_1937s.json"))
    ap.add_argument("--examples", type=int, default=14)
    ap.add_argument("--out", default=str(ROOT / "results/omitted_phonemes.json"))
    a = ap.parse_args()

    g2p = G2P.from_files(a.lex, ROOT / "configs/phonemap.yaml")
    toks = aligned_to_side(Path(a.aligned), sid="gold")["tokens"]
    groups = [list(g) for _, g in itertools.groupby(toks, key=lambda t: t["utt"])]
    words = [Word(w["text"], w["start"], w["end"], w["prob"]) for ws in json.loads(Path(a.asr).read_text()) for w in ws]
    words, _ = normalize_fillers([w for w in words if norm_word(w.text)])
    asr = [(norm_word(w.text), (w.start + w.end) / 2) for w in words]
    n_d = sum(t["label"] in GOLD_TYPES for t in toks)
    print(f"lecture: {len(toks)} tokens, {n_d} disfluent")
    results, ex_main = {}, []
    for name, (path, kind) in SOURCES.items():
        stream = phone_stream(path, kind, g2p.ipa)
        for cond, asr_arg in (("gold transcript, disfluencies ignored", None), ("Whisper's words", asr)):
            r, ex = analyse(groups, g2p, stream, asr_arg, a.examples)
            show(name, cond, r)
            results[f"{name} | {cond}"] = r
            if kind == "ipa" and asr_arg is None:
                ex_main = ex
    print("\nexamples: omitted-phoneme runs of the espeak recognizer against the gold transcript with disfluencies ignored")
    print("(run = consecutive omitted phones; 'found' = the disfluent tokens whose phones it matches in the verbatim alignment)")
    good = [e for e in ex_main if e[2]][:a.examples]
    bad = [e for e in ex_main if not e[2]][:6]
    for tag, rows in (("DISFLUENCY FOUND", good), ("NOT a disfluency", bad)):
        print(f"--- {tag}")
        for run, ph, d, owners, _ in rows:
            seen = list(dict.fromkeys((o["spoken"], o["label"]) for o in d))
            what = ", ".join(f"{w} [{l}]" for w, l in seen) if d else (
                "explained by fluent word(s): " + ", ".join(sorted({o["spoken"] for o in owners})) if owners else "unexplained by anything")
            print(f"   {' '.join(ph):24s} -> {what}")
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(results, indent=2))
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
