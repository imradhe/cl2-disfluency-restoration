"""Two recognizer streams: the [REC2] input layout, windows, checkpoint detection, the character decoder and the
time-cut phone streams of a lecture."""
import json

import numpy as np
import pytest
import torch

from model.seq import MAX_LEN, MAX_LEN2, SeqDataset, collate_seq, limits, word_cost
from nptel.streams import phone_stream, phones_between, utterance_rows, utterance_stretches
from phones.channel import ProfileNoise, fit_profile
from phones.noise import PhoneNoise
from pipeline.asr import Word
from pipeline.charrec import greedy_tokens
from pipeline.phonerec import RecPhone
from pipeline.run import ckpt_streams
from pipeline.windows import make_windows

from test_seq import PH, VOCAB, FakeTok, example


def two(ex_list, tokz=None, **kw):
    tokz = tokz or FakeTok()
    return SeqDataset(ex_list, tokz, VOCAB, two_streams=True, **kw), tokz


def test_limits_and_word_cost_grow_with_a_second_stream():
    assert limits(1)[1] == MAX_LEN and limits(2)[1] == MAX_LEN2 and limits(2)[0] > limits(1)[0]
    assert word_cost(4, 2) > word_cost(4) and word_cost(4) == 2.0 + 2.1 * 4


def test_two_stream_input_layout_has_rec2_once_and_the_phones_of_both_streams():
    ds, tokz = two([example(rec=["s", "ow", "ah", "m"], rec2=["s", "ow", "aa"])])
    it = ds[0]
    ids, rec2 = it["ids"], tokz.convert_tokens_to_ids("[REC2]")
    assert ids.count(rec2) == 1 and ids[-1] == 2                                            # [SEP] closes the input
    k = ids.index(rec2)
    n_a = it["types"].index(1)
    assert [ids[n_a + j] for j in range(4)] == [tokz.convert_tokens_to_ids(f"<ph:{p}>") for p in ["s", "ow", "ah", "m"]]
    assert ids[k + 1:-1] == [tokz.convert_tokens_to_ids(f"<ph:{p}>") for p in ["s", "ow", "aa"]]
    assert set(it["types"][n_a:]) == {1} and len(it["types"]) == len(ids)
    one = SeqDataset([example(rec=["s", "ow", "ah", "m"])], tokz, VOCAB)[0]               # the one-stream layout has no [REC2]
    assert rec2 not in one["ids"]


def test_stream_two_is_derived_from_the_clean_phones_through_its_own_noise_and_aux_labels_follow_both_streams():
    ex = example(rec=["s", "ow", "ah", "m"], rec_role=[0, 0, 1, 1], rec_ptr=[0, 0, 1, 1])
    plain, tokz = two([ex])
    it = plain[0]
    assert len(it["rec_pos"]) == 8 and it["rec_role"] == [0, 0, 1, 1] * 2 and it["rec_ptr"] == [0, 0, 1, 1] * 2   # both streams, clean
    ins = PhoneNoise(p_del=0.0, p_sub=0.0, p_ins=1.0, seed=0)
    noisy, _ = two([ex], noise=None, noise2=ins)
    it = noisy[0]
    assert len(it["rec_pos"]) == 4 + 8 and it["rec_role"][4:] == [0, 0, 0, 0, 1, 1, 1, 1]                           # stream 2 got insertions
    assert len(set(it["rec_pos"])) == len(it["rec_pos"]) and all(it["ids"][p] >= 100 for p in it["rec_pos"])
    prof = fit_profile([("O", ["k", "ae", "t"], ["k", "ae", "t"])] * 30)
    ex = example(rec=["s", "ow", "ah", "m"], rec_role=[0, 0, 1, 1], rec_ptr=[0, 0, 1, 1], rec_tok=[0, 0, 1, 1], tok_lab=["O", "FILLER_HESITATION"])
    ds, _ = two([ex], noise=ProfileNoise(prof, 1.0, seed=1), noise2=ProfileNoise(prof, 1.0, seed=2))
    for _ in range(20):
        it = ds[0]
        assert len(it["rec_pos"]) == len(it["rec_role"]) == len(it["rec_ptr"])


def test_real_rec2_phones_are_used_as_given_and_cannot_carry_aux_labels():
    ds, tokz = two([example(rec=["s", "ow"], rec2=["k", "ae", "t"])], noise2=PhoneNoise(p_del=1.0, seed=0))
    it = ds[0]
    assert it["ids"][it["ids"].index(tokz.convert_tokens_to_ids("[REC2]")) + 1:-1] == [tokz.convert_tokens_to_ids(f"<ph:{p}>") for p in ["k", "ae", "t"]]
    bad, _ = two([example(rec=["s", "ow"], rec2=["k"], rec_role=[0, 0], rec_ptr=[0, 0])])
    with pytest.raises(AssertionError):
        bad[0]


def test_truncation_shares_the_room_between_the_two_streams():
    ex = example(rec=["s"] * 40, rec2=["k"] * 10)
    ds, tokz = two([ex], max_len=60)
    it = ds[0]
    assert len(it["ids"]) <= 60 and ds.truncated == 1
    k = it["ids"].index(tokz.convert_tokens_to_ids("[REC2]"))
    n_b = len(it["ids"]) - 1 - (k + 1)
    assert n_b == 10                                                                         # the short stream is kept whole
    ds2, _ = two([example(rec=["s"] * 40, rec2=["k"] * 40)], max_len=60)
    it = ds2[0]
    k = it["ids"].index(tokz.convert_tokens_to_ids("[REC2]"))
    a, b = k - it["types"].index(1), len(it["ids"]) - 1 - (k + 1)
    assert abs(a - b) <= 1 and len(it["ids"]) <= 60                                          # two long streams split evenly


def test_two_stream_model_forward_backward_with_a_tiny_encoder(monkeypatch):
    from transformers import BertConfig, BertModel

    import model.bert_seq as bs
    cfg = BertConfig(vocab_size=200, hidden_size=32, num_hidden_layers=1, num_attention_heads=2, intermediate_size=64,
                     max_position_embeddings=128)
    monkeypatch.setattr(bs.AutoModel, "from_pretrained", lambda name: BertModel(cfg))
    m = bs.BertSeq("tiny", 220, len(VOCAB))
    ex = example(rec=["s", "ow", "ah", "m"], rec_role=[0, 0, 1, 1], rec_ptr=[0, 0, 1, 1])
    ds, _ = two([ex, ex], noise=PhoneNoise(seed=0), noise2=PhoneNoise(seed=1))
    out = m(collate_seq([ds[0], ds[1]]))
    out["loss"].backward()
    assert torch.isfinite(out["loss"]) and float(out["role_loss"]) > 0


def rp(ph, t):
    return RecPhone(ph, t, t + 0.04, 0.9)


class G2P:
    def phones(self, w):
        return PH.get(w, ["ax"])


def test_make_windows_cuts_the_second_stream_at_the_same_times():
    words = [Word("cat", k * 0.5, k * 0.5 + 0.3) for k in range(8)]
    a = [rp("k", w.start + 0.02) for w in words]
    b = [rp("g", w.start + 0.05) for w in words] + [rp("n", 4.2)]
    wins = make_windows(words, a, G2P(), 0.0, 4.5, max_words=5, rec2=b)
    assert [len(w.words) for w in wins] == [5, 3] and sum(len(w.rec) for w in wins) == 8
    assert [len(w.rec2) for w in wins] == [5, 4] and [x for w in wins for x in w.rec2].count("g") == 8     # same boundary rule as rec
    ex = wins[0].example("x", 0)
    assert ex["rec2"] == wins[0].rec2
    assert "rec2" not in make_windows(words, a, G2P(), 0.0, 4.5)[0].example("x", 0)                          # one stream: unchanged
    (lone,) = make_windows([], [], G2P(), 0.0, 2.0, rec2=[rp("ah", 1.0)])
    assert lone.words == [] and lone.rec == [] and lone.rec2 == ["ah"]


def test_ckpt_streams_reads_args_json(tmp_path):
    assert ckpt_streams(tmp_path) == 1
    (tmp_path / "args.json").write_text(json.dumps({"two_streams": True}))
    assert ckpt_streams(tmp_path) == 2
    (tmp_path / "args.json").write_text(json.dumps({"epochs": 3}))
    assert ckpt_streams(tmp_path) == 1


def test_greedy_tokens_merges_repeats_and_drops_blank_and_word_delimiter():
    vocab = {0: "<s>", 1: "<pad>", 2: "|", 3: "క", 4: "ా"}
    ids = np.array([1, 3, 3, 1, 3, 2, 4, 4, 1])
    probs = np.array([0.9, 0.8, 0.6, 0.9, 0.7, 0.9, 0.5, 0.7, 0.9])
    toks = greedy_tokens(ids, probs, vocab, blank=1, t_off=1.0)
    assert [t["tok"] for t in toks] == ["క", "క", "ా"]                                       # a blank between repeats keeps both
    assert toks[0]["start"] == 1.02 and toks[0]["end"] == 1.06 and toks[0]["p"] == pytest.approx(0.7)
    assert greedy_tokens(np.array([1, 1]), np.array([0.9, 0.9]), vocab, 1, 0.0) == []


class Ipa:
    def lookup(self, tok):
        return {"ə": ["ax"], "k": ["k"], "ɑː": ["aa"], "x": []}.get(tok, [])


def test_phone_streams_are_cut_by_time_for_both_recognizers(tmp_path):
    ipa = tmp_path / "ipa.jsonl"
    seg = {"seg": 0, "t0": 0, "t1": 5, "tokens": [{"tok": "k", "start": 0.0, "end": 0.04, "p": 1}, {"tok": "ə", "start": 0.5, "end": 0.54, "p": 1},
                                                   {"tok": "x", "start": 0.6, "end": 0.64, "p": 1}, {"tok": "ɑː", "start": 1.0, "end": 1.08, "p": 1}]}
    ipa.write_text(json.dumps(seg) + "\n" + json.dumps(seg) + "\n")                          # overlapping segments are deduplicated
    st = phone_stream(ipa, "ipa", Ipa())
    assert st[1] == ["k", "ax", "aa"] and phones_between(st, 0.4, 0.6) == ["ax"] and phones_between(st, 2.0, 3.0) == []
    tel = tmp_path / "tel.jsonl"
    tel.write_text(json.dumps({"seg": 0, "t0": 0, "t1": 5, "tokens": [{"tok": "న", "start": 0.0, "end": 0.04, "p": 1},
                                                                      {"tok": "ఆ", "start": 0.5, "end": 0.54, "p": 1}]}) + "\n")
    st = phone_stream(tel, "tel", Ipa())
    assert st[1] == ["n", "ah", "aa"]                                                        # inherent vowel kept in time order
    with pytest.raises(ValueError):
        phone_stream(tel, "nope", Ipa())


def test_utterance_stretches_and_rows_use_each_utterances_time_span(tmp_path):
    toks = [{"utt": "a", "label": "O", "spoken": "cat", "start": 0.0, "end": 0.4}, {"utt": "a", "label": "NOISE", "spoken": "[n]", "start": 0.4, "end": 0.5},
            {"utt": "a", "label": "FILLER_HESITATION", "spoken": "uh", "start": 0.6, "end": 0.9},
            {"utt": "b", "label": "O", "spoken": "cat", "start": 2.0, "end": 2.4}]
    stream = ([0.1, 0.2, 0.3, 0.7, 2.2], ["k", "ae", "t", "aa", "k"])
    st = utterance_stretches(toks, G2P(), stream)
    assert [items for items, _ in st] == [[("O", ["k", "ae", "t"]), ("FILLER_HESITATION", ["ax"])], [("O", ["k", "ae", "t"])]]
    assert [hyp for _, hyp in st] == [["k", "ae", "t", "aa"], ["k"]]                          # the utterance-b phone does not leak into a
    rows = utterance_rows(toks, G2P(), stream)
    assert [r["label"] for r in rows] == ["O", "FILLER_HESITATION", "O"] and rows[0]["out"] == ["k", "ae", "t"]
