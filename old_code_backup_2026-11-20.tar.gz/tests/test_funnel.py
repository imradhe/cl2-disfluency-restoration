"""The 'did the recognizer hear this token?' rule of scripts/disfluency_funnel.py."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from disfluency_funnel import heard, lcs  # noqa: E402


def test_lcs_is_the_longest_common_subsequence_in_order():
    assert lcs(["k", "ae", "t"], ["k", "ae", "t"]) == 3
    assert lcs(["k", "ae", "t"], ["k", "t"]) == 2 and lcs(["k", "ae", "t"], ["t", "k"]) == 1
    assert lcs([], ["a"]) == 0 and lcs(["a"], []) == 0


def test_a_token_is_heard_when_half_of_its_phones_are_found_in_order():
    assert heard(["k", "ae", "t"], ["k", "ax", "t"], "O")                   # 2 of 3
    assert not heard(["k", "ae", "t"], ["t"], "REPETITION")                  # 1 of 3
    assert not heard(["k", "ae", "t"], [], "O") and not heard([], ["k"], "O")


def test_the_one_phone_uh_is_heard_when_any_vowel_is_written():
    assert heard(["ah"], ["ax"], "FILLER_HESITATION") and heard(["ah"], ["s", "aa"], "FILLER_HESITATION")
    assert not heard(["ah"], ["s", "n"], "FILLER_HESITATION") and not heard(["ah"], [], "FILLER_HESITATION")
    assert not heard(["ah"], ["ax"], "FILLER_DM")                             # other labels: phones must match
