"""Telugu script -> Switchboard phones: inherent vowels, vowel signs, virama, independent vowels."""
from phones.telugu import telugu_to_swb


def toks(s: str) -> list[dict]:
    return [{"tok": c, "start": 0.02 * i, "end": 0.02 * (i + 1), "p": 0.9} for i, c in enumerate(s)]


def phones(s: str) -> list[str]:
    return [p["ph"] for p in telugu_to_swb(toks(s))]


def test_a_bare_consonant_letter_carries_the_inherent_vowel():
    assert phones("నవ") == ["n", "ah", "v", "ah"]                # "now" as a Telugu recognizer writes it
    assert phones("క") == ["k", "ah"]


def test_vowel_signs_replace_the_inherent_vowel_and_virama_removes_it():
    assert phones("కా") == ["k", "aa"] and phones("కి") == ["k", "ih"] and phones("కో") == ["k", "ow"]
    assert phones("క్ర") == ["k", "r", "ah"]                      # a consonant cluster: no vowel between k and r
    assert phones("స్") == ["s"]                                  # word-final consonant without a vowel
    assert phones("కృ") == ["k", "r", "ih"]


def test_independent_vowels_and_the_filled_pause_letters():
    assert phones("ఆ") == ["aa"] and phones("అ") == ["ah"] and phones("ఉ") == ["uh"]
    assert phones("నఆ") == ["n", "ah", "aa"]                      # the consonant's inherent vowel is flushed before a vowel letter
    assert phones("్") == [] and phones("") == []                   # a lone virama (seen for some uh's) writes no phone


def test_nasals_unknown_characters_and_times():
    assert phones("కం") == ["k", "ah", "m"]
    assert phones("కxన") == ["k", "ah", "n", "ah"]                  # a foreign character ends the akshara
    out = telugu_to_swb(toks("నవ"))
    assert [(p["start"], p["end"]) for p in out] == [(0.0, 0.02), (0.0, 0.02), (0.02, 0.04), (0.02, 0.04)]   # inherent vowel: consonant's times
    assert all(p["tok"] in "నవ" and p["p"] == 0.9 for p in out)
