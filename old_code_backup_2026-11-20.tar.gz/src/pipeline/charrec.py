"""Second phone recognizer: a character-level Telugu CTC model (letters -> Switchboard phones).

``anuragshas/wav2vec2-large-xlsr-53-telugu`` writes Telugu letters for any speech; on the NPTEL lecture it writes a
vowel for ~70% of the "uh"s that the wav2vec2/espeak recognizer leaves out about half of the time, but it is a much
noisier stream for ordinary words (README, "Other phone recognizers"). The letters are mapped to phones by
``phones.telugu`` and returned like the espeak recognizer's :class:`RecPhone`.
"""
from __future__ import annotations

import numpy as np

from phones.telugu import telugu_to_swb

from .phonerec import RecPhone, STRIDE

MODEL2 = "anuragshas/wav2vec2-large-xlsr-53-telugu"
_SKIP = ("|", "<s>", "</s>", "<unk>", " ")


def greedy_tokens(ids: np.ndarray, probs: np.ndarray, vocab: dict[int, str], blank: int, t_off: float) -> list[dict]:
    """Greedy CTC of a character model: merge repeats, drop the blank and the word delimiter. Times from the frames."""
    out, i, n = [], 0, len(ids)
    while i < n:
        j = i
        while j + 1 < n and ids[j + 1] == ids[i]:
            j += 1
        tok = vocab.get(int(ids[i]), "")
        if ids[i] != blank and tok not in _SKIP:
            out.append({"tok": tok, "start": round(t_off + i * STRIDE, 3), "end": round(t_off + (j + 1) * STRIDE, 3),
                        "p": round(float(probs[i:j + 1].mean()), 3)})
        i = j + 1
    return out


class CharPhoneRecognizer:
    def __init__(self, model: str = MODEL2, device: str | None = None) -> None:
        import torch
        from transformers import AutoFeatureExtractor, AutoTokenizer, Wav2Vec2ForCTC

        self.torch = torch
        self.dev = torch.device(device or ("mps" if torch.backends.mps.is_available() else "cpu"))
        self.fe = AutoFeatureExtractor.from_pretrained(model)
        tok = AutoTokenizer.from_pretrained(model)
        self.vocab = {i: t for t, i in tok.get_vocab().items()}
        self.blank = tok.pad_token_id
        self.model = Wav2Vec2ForCTC.from_pretrained(model).to(self.dev).eval()

    def recognize(self, audio: np.ndarray, offset: float = 0.0) -> list[RecPhone]:
        torch = self.torch
        with torch.no_grad():
            inp = self.fe(audio, sampling_rate=16000, return_tensors="pt")
            probs = self.model(inp.input_values.to(self.dev)).logits[0].float().softmax(-1)
            ids, pmax = probs.argmax(-1).cpu().numpy(), probs.max(-1).values.cpu().numpy()
        return [RecPhone(**p) for p in telugu_to_swb(greedy_tokens(ids, pmax, self.vocab, self.blank, offset))]
