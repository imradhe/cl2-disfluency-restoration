"""Telugu script (the output of a character-level Telugu CTC recognizer) -> Switchboard 42-phone symbols.

Telugu is an abugida: a consonant letter carries an inherent short "a" unless a vowel sign follows it or a virama
(్) cancels it. A character-level recognizer run on English speech writes English words in Telugu letters
(e.g. "నవ" for "now"); mapping those letters to phones gives a phone stream that can stand in for the
wav2vec2/espeak recognizer. The mapping is deliberately coarse (retroflex and aspirated consonants collapse onto the
nearest English phone). Spaces are not part of the stream, so a word-final consonant cannot be told from a
word-internal one and gets its inherent "a" like any other.
"""
from __future__ import annotations

INHERENT = "ah"
INDEPENDENT = {"అ": ["ah"], "ఆ": ["aa"], "ఇ": ["ih"], "ఈ": ["iy"], "ఉ": ["uh"], "ఊ": ["uw"], "ఋ": ["r", "ih"],
               "ఎ": ["eh"], "ఏ": ["ey"], "ఐ": ["ay"], "ఒ": ["ao"], "ఓ": ["ow"], "ఔ": ["aw"]}
SIGNS = {"ా": ["aa"], "ి": ["ih"], "ీ": ["iy"], "ు": ["uh"], "ూ": ["uw"], "ృ": ["r", "ih"], "ె": ["eh"], "ే": ["ey"],
         "ై": ["ay"], "ొ": ["ao"], "ో": ["ow"], "ౌ": ["aw"]}
CONSONANTS = {"క": "k", "ఖ": "k", "గ": "g", "ఘ": "g", "ఙ": "ng", "చ": "ch", "ఛ": "ch", "జ": "jh", "ఝ": "jh", "ఞ": "n",
              "ట": "t", "ఠ": "t", "డ": "d", "ఢ": "d", "ణ": "n", "త": "t", "థ": "th", "ద": "d", "ధ": "dh", "న": "n",
              "ప": "p", "ఫ": "f", "బ": "b", "భ": "b", "మ": "m", "య": "y", "ర": "r", "ఱ": "r", "ల": "l", "ళ": "l",
              "వ": "v", "శ": "sh", "ష": "sh", "స": "s", "హ": "hh"}
VIRAMA = "్"
NASAL = {"ం": "m", "ఁ": "n", "ః": "hh"}                  # anusvara, candrabindu, visarga


def telugu_to_swb(tokens: list[dict]) -> list[dict]:
    """Recognizer tokens (``{"tok", "start", "end", "p"}`` in time order, one Telugu character each) -> phones
    ``{"ph", "start", "end", "p", "tok"}``. A phone takes the times of the character it comes from; the inherent
    vowel of a consonant takes the times of the consonant."""
    out: list[dict] = []
    pending: dict | None = None                          # last consonant, whose inherent vowel is still undecided

    def emit(ph: str, t: dict) -> None:
        out.append({"ph": ph, "start": t["start"], "end": t["end"], "p": t.get("p", 1.0), "tok": t["tok"]})

    def flush() -> None:
        nonlocal pending
        if pending is not None:
            emit(INHERENT, pending)
            pending = None

    for t in tokens:
        for ch in t["tok"]:
            if ch in CONSONANTS:
                flush()
                emit(CONSONANTS[ch], t)
                pending = t
            elif ch in SIGNS:
                pending = None
                for ph in SIGNS[ch]:
                    emit(ph, t)
            elif ch == VIRAMA:
                pending = None
            elif ch in INDEPENDENT:
                flush()
                for ph in INDEPENDENT[ch]:
                    emit(ph, t)
            elif ch in NASAL:
                flush()
                emit(NASAL[ch], t)
            else:                                        # anything else (digits, latin, punctuation) ends the akshara
                flush()
    flush()
    return out
