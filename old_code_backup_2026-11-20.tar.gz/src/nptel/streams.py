"""Recognized phone streams of an NPTEL lecture, cut by time, for either recognizer.

``kind`` "ipa": the wav2vec2/espeak recognizer (IPA tokens -> Switchboard phones through the IPA map);
``kind`` "tel": the Telugu character recognizer (Telugu letters -> Switchboard phones, ``phones.telugu``).
Every phone carries the centre of the recognizer token it came from, so a window takes the phones of whole tokens.
"""
from __future__ import annotations

import bisect
import itertools
from pathlib import Path

from phones.channel import stretch_outcomes
from phones.telugu import telugu_to_swb

from .recognized import load_recognized


def phone_stream(path: Path, kind: str, ipa) -> tuple[list[float], list[str]]:
    """Time-sorted ``(centres, phones)`` of one recognizer's output file (overlapping segments deduplicated)."""
    _, toks = load_recognized(path)
    if kind == "ipa":
        pairs = [((t["start"] + t["end"]) / 2, p) for t in toks for p in ipa.lookup(t["tok"])]
    elif kind == "tel":
        pairs = [((p["start"] + p["end"]) / 2, p["ph"]) for p in telugu_to_swb(toks)]
    else:
        raise ValueError(f"unknown recognizer kind {kind!r}")
    pairs.sort(key=lambda x: x[0])
    return [c for c, _ in pairs], [p for _, p in pairs]


def phones_between(stream: tuple[list[float], list[str]], t0: float, t1: float) -> list[str]:
    centres, phones = stream
    return phones[bisect.bisect_left(centres, t0):bisect.bisect_right(centres, t1)]


def utterance_stretches(toks: list[dict], g2p, stream: tuple[list[float], list[str]]) -> list[tuple[list[tuple[str, list[str]]], list[str]]]:
    """One ``([(label, G2P phones)] of the gold tokens, recognized phones of the utterance's time span)`` per utterance
    of the forced-aligned lecture (NOISE tokens and tokens without G2P phones are left out of the reference)."""
    out = []
    for _, grp in itertools.groupby(toks, key=lambda t: t["utt"]):
        grp = list(grp)
        items = [(t["label"], list(g2p.phones(t["spoken"]))) for t in grp if t["label"] != "NOISE"]
        items = [(lab, ref) for lab, ref in items if ref]
        if items:
            out.append((items, phones_between(stream, grp[0]["start"], grp[-1]["end"])))
    return out


def utterance_rows(toks: list[dict], g2p, stream: tuple[list[float], list[str]]) -> list[dict]:
    """``stretch_outcomes`` of every utterance, flattened (input of ``phones.channel.fit_profile``)."""
    return [r for items, hyp in utterance_stretches(toks, g2p, stream) for r in stretch_outcomes(items, hyp)]
